# Party - Premium Nightlife App

A high-end mobile nightlife discovery app with cyber-noir aesthetics featuring:

## Features

### 1. Discovery Feed (Tinder-Style)
- Swipeable glassmorphism cards with vibrant club photography
- Drag left to skip, drag right to like
- Real-time swipe indicators (NOPE/LIKE)
- Animated card stack with depth
- Immersive background glow effects

### 2. Digital Wallet
- Futuristic balance card with gradient backgrounds
- Active & upcoming ticket management
- Animated QR codes with glowing accents
- Download and share ticket functionality
- Real-time ticket status indicators

### 3. Event Details
- Full-screen immersive hero images
- Dark mode cyber-noir aesthetic
- Comprehensive event information
- DJ lineup with schedules
- Stats grid with ratings, attendees, and trending status
- Fixed CTA with gradient effects

## Design System

### Color Palette (Cyber-Noir)
- Primary Purple: `#A855F7`, `#C026D3`
- Electric Blue: `#3B82F6`, `#06B6D4`
- Accent Pink: `#EC4899`
- Dark Background: Pure black (`#000000`)

### Typography
- Font Family: Inter (fallback to SF Pro Display/Text)
- High contrast text with gradient accents
- Professional weight hierarchy

### Effects
- Glassmorphism cards (`backdrop-blur-2xl`)
- Neon glow shadows
- Smooth transitions and animations
- Pulsing background gradients

## Navigation
- Bottom navigation bar with icons
- Three main sections: Discover, Wallet, Profile
- Smooth routing with React Router

## Tech Stack
- React with TypeScript
- Motion (formerly Framer Motion) for animations
- Tailwind CSS v4 for styling
- React Router for navigation
- Lucide React for icons
