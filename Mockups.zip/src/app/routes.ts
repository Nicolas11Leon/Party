import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { DiscoveryFeed } from "./components/DiscoveryFeed";
import { Wallet } from "./components/Wallet";
import { EventDetails } from "./components/EventDetails";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: DiscoveryFeed },
      { path: "wallet", Component: Wallet },
      { path: "event/:id", Component: EventDetails },
    ],
  },
]);
