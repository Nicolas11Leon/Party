import { Outlet } from "react-router";
import { BottomNav } from "./BottomNav";

export function Root() {
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <div className="pb-20">
        <Outlet />
      </div>
      <BottomNav />
    </div>
  );
}
