import { useState } from "react";
import { motion, useMotionValue, useTransform, AnimatePresence } from "motion/react";
import { MapPin, Clock, Users, Star, X, Heart } from "lucide-react";

const events = [
  {
    id: 1,
    name: "NEON NIGHTS",
    venue: "Skybar Rooftop",
    image: "https://images.unsplash.com/photo-1755914990988-2ea83eb5ea73?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb29mdG9wJTIwYmFyJTIwY2l0eSUyMHNreWxpbmUlMjBuaWdodHxlbnwxfHx8fDE3NzQ0MDk0NTh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    location: "Downtown LA",
    time: "10:00 PM - 4:00 AM",
    attendees: "2.3k",
    rating: 4.8,
    price: "$25",
  },
  {
    id: 2,
    name: "ELECTRIC PULSE",
    venue: "The Vault",
    image: "https://images.unsplash.com/photo-1758179764880-7513421d202a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodGNsdWUlMjBuZW9uJTIwbGlnaHRzJTIwcGFydHl8ZW58MXx8fHwxNzc0NDA5NDU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    location: "West Hollywood",
    time: "11:00 PM - 5:00 AM",
    attendees: "1.8k",
    rating: 4.9,
    price: "$35",
  },
  {
    id: 3,
    name: "COSMIC LOUNGE",
    venue: "Aurora Club",
    image: "https://images.unsplash.com/photo-1603545554154-c7c805c46fa8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjbHViJTIwaW50ZXJpb3IlMjBwdXJwbGV8ZW58MXx8fHwxNzc0NDA5NDU3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    location: "Beverly Hills",
    time: "9:00 PM - 2:00 AM",
    attendees: "1.2k",
    rating: 4.7,
    price: "$40",
  },
  {
    id: 4,
    name: "BASS DISTRICT",
    venue: "Underground",
    image: "https://images.unsplash.com/photo-1763630055072-70b8b56ee0f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxESiUyMGNvbmNlcnQlMjBzdGFnZSUyMGxpZ2h0c3xlbnwxfHx8fDE3NzQ0MDk0NTh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    location: "Arts District",
    time: "10:00 PM - 6:00 AM",
    attendees: "3.1k",
    rating: 4.9,
    price: "$30",
  },
  {
    id: 5,
    name: "VELOCITY",
    venue: "Momentum",
    image: "https://images.unsplash.com/photo-1624929303661-22c5bce0169b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwbXVzaWMlMjBmZXN0aXZhbCUyMGNyb3dkfGVufDF8fHx8MTc3NDQwNTE4M3ww&ixlib=rb-4.1.0&q=80&w=1080",
    location: "Santa Monica",
    time: "11:00 PM - 4:00 AM",
    attendees: "2.7k",
    rating: 4.8,
    price: "$28",
  },
  {
    id: 6,
    name: "NOIR SOCIETY",
    venue: "The Manor",
    image: "https://images.unsplash.com/photo-1774008931543-f3576c222a46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb2NrdGFpbCUyMGJhciUyMG5lb258ZW58MXx8fHwxNzc0NDA5NDU5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    location: "Hollywood Hills",
    time: "9:00 PM - 3:00 AM",
    attendees: "950",
    rating: 4.9,
    price: "$50",
  },
];

export function DiscoveryFeed() {
  const [cards, setCards] = useState(events);
  const [currentIndex, setCurrentIndex] = useState(0);

  const removeCard = (liked: boolean) => {
    if (currentIndex < cards.length) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-950/20 to-black pt-12 px-4 relative overflow-hidden">
      {/* Animated Background Glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
      
      {/* Header */}
      <div className="max-w-md mx-auto mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent mb-2">
          Party
        </h1>
        <p className="text-gray-400 text-sm">Discover tonight's hottest events</p>
      </div>

      {/* Card Stack */}
      <div className="max-w-md mx-auto h-[600px] relative">
        <AnimatePresence>
          {cards.map((event, index) => {
            if (index < currentIndex) return null;
            if (index > currentIndex + 2) return null;

            return (
              <Card
                key={event.id}
                event={event}
                index={index - currentIndex}
                onSwipe={removeCard}
              />
            );
          })}
        </AnimatePresence>

        {currentIndex >= cards.length && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4">🎉</div>
              <h3 className="text-2xl font-bold text-white mb-2">No More Events</h3>
              <p className="text-gray-400">Check back later for more!</p>
              <button
                onClick={() => {
                  setCards(events);
                  setCurrentIndex(0);
                }}
                className="mt-6 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full text-white font-semibold hover:from-purple-500 hover:to-blue-500 transition-all"
              >
                Restart
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="max-w-md mx-auto mt-8 flex justify-center gap-6">
        <button
          onClick={() => removeCard(false)}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-red-500/20 to-pink-500/20 backdrop-blur-xl border border-red-500/30 flex items-center justify-center hover:scale-110 transition-transform"
        >
          <X className="w-8 h-8 text-red-500" />
        </button>
        <button
          onClick={() => removeCard(true)}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500/20 to-blue-500/20 backdrop-blur-xl border border-purple-500/30 flex items-center justify-center hover:scale-110 transition-transform"
        >
          <Heart className="w-8 h-8 text-purple-500" />
        </button>
      </div>
    </div>
  );
}

interface CardProps {
  event: typeof events[0];
  index: number;
  onSwipe: (liked: boolean) => void;
}

function Card({ event, index, onSwipe }: CardProps) {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_: any, info: any) => {
    if (Math.abs(info.offset.x) > 150) {
      onSwipe(info.offset.x > 0);
    }
  };

  return (
    <motion.div
      className="absolute inset-0"
      style={{
        x,
        rotate,
        opacity,
        zIndex: 10 - index,
      }}
      initial={{ scale: 1 - index * 0.05, y: index * 10 }}
      animate={{ scale: 1 - index * 0.05, y: index * 10 }}
      exit={{ x: 1000, opacity: 0, transition: { duration: 0.3 } }}
      drag={index === 0 ? "x" : false}
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      whileTap={{ cursor: "grabbing" }}
    >
      <div className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl">
        {/* Background Image */}
        <img
          src={event.image}
          alt={event.name}
          className="absolute inset-0 w-full h-full object-cover"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

        {/* Glassmorphism Card */}
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="bg-white/10 backdrop-blur-2xl rounded-2xl p-6 border border-white/20 shadow-2xl">
            {/* Event Name & Venue */}
            <div className="mb-4">
              <h2 className="text-3xl font-bold text-white mb-1 tracking-tight">
                {event.name}
              </h2>
              <p className="text-purple-300 text-lg font-medium">{event.venue}</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="flex items-center gap-2 bg-purple-500/20 backdrop-blur-xl rounded-xl px-3 py-2 border border-purple-500/30">
                <MapPin className="w-4 h-4 text-purple-400" />
                <span className="text-white text-sm">{event.location}</span>
              </div>
              <div className="flex items-center gap-2 bg-blue-500/20 backdrop-blur-xl rounded-xl px-3 py-2 border border-blue-500/30">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-white text-sm">{event.time.split(" - ")[0]}</span>
              </div>
              <div className="flex items-center gap-2 bg-pink-500/20 backdrop-blur-xl rounded-xl px-3 py-2 border border-pink-500/30">
                <Users className="w-4 h-4 text-pink-400" />
                <span className="text-white text-sm">{event.attendees} going</span>
              </div>
              <div className="flex items-center gap-2 bg-cyan-500/20 backdrop-blur-xl rounded-xl px-3 py-2 border border-cyan-500/30">
                <Star className="w-4 h-4 text-cyan-400 fill-cyan-400" />
                <span className="text-white text-sm">{event.rating}</span>
              </div>
            </div>

            {/* Price Tag */}
            <div className="flex justify-between items-center">
              <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                {event.price}
              </div>
              <div className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full text-white text-sm font-semibold shadow-lg shadow-purple-500/50">
                Get Ticket
              </div>
            </div>
          </div>
        </div>

        {/* Swipe Indicators */}
        <motion.div
          className="absolute top-10 left-10 text-6xl font-bold text-red-500 rotate-[-20deg] opacity-0"
          style={{
            opacity: useTransform(x, [-200, -50, 0], [1, 0.5, 0]),
          }}
        >
          NOPE
        </motion.div>
        <motion.div
          className="absolute top-10 right-10 text-6xl font-bold text-green-500 rotate-[20deg] opacity-0"
          style={{
            opacity: useTransform(x, [0, 50, 200], [0, 0.5, 1]),
          }}
        >
          LIKE
        </motion.div>
      </div>
    </motion.div>
  );
}