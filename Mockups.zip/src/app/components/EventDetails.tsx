import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  ArrowLeft,
  MapPin,
  Clock,
  Users,
  Star,
  Heart,
  Share2,
  Music,
  Sparkles,
  TrendingUp,
  Calendar,
} from "lucide-react";

export function EventDetails() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Image */}
      <div className="relative h-[400px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1758179764880-7513421d202a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodGNsdWIlMjBuZW9uJTIwbGlnaHRzJTIwcGFydHl8ZW58MXx8fHwxNzc0NDA5NDU3fDA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Event"
          className="w-full h-full object-cover"
        />
        
        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />

        {/* Glow Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-purple-600/30 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-blue-600/30 rounded-full blur-[100px]" />

        {/* Header Actions */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center">
          <button
            onClick={() => navigate("/")}
            className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:bg-black/70 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:bg-black/70 transition-all">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:bg-black/70 transition-all">
              <Heart className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Event Title */}
        <div className="absolute bottom-6 left-0 right-0 px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <div className="px-3 py-1 rounded-full bg-gradient-to-r from-purple-600/80 to-pink-600/80 backdrop-blur-xl border border-purple-400/30 text-white text-xs font-semibold">
                🔥 Trending
              </div>
              <div className="px-3 py-1 rounded-full bg-gradient-to-r from-blue-600/80 to-cyan-600/80 backdrop-blur-xl border border-blue-400/30 text-white text-xs font-semibold">
                EDM
              </div>
            </div>
            <h1 className="text-5xl font-bold text-white mb-2 tracking-tight">
              NEON NIGHTS
            </h1>
            <p className="text-xl text-purple-300 font-medium">Skybar Rooftop</p>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 pb-32">
        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-4 gap-3 -mt-6 mb-8"
        >
          <div className="bg-gradient-to-br from-purple-900/50 to-purple-950/50 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-4 text-center">
            <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">4.9</p>
            <p className="text-xs text-gray-400">Rating</p>
          </div>
          <div className="bg-gradient-to-br from-blue-900/50 to-blue-950/50 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-4 text-center">
            <Users className="w-5 h-5 text-blue-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">2.3k</p>
            <p className="text-xs text-gray-400">Going</p>
          </div>
          <div className="bg-gradient-to-br from-pink-900/50 to-pink-950/50 backdrop-blur-xl border border-pink-500/30 rounded-2xl p-4 text-center">
            <Music className="w-5 h-5 text-pink-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">5</p>
            <p className="text-xs text-gray-400">DJs</p>
          </div>
          <div className="bg-gradient-to-br from-cyan-900/50 to-cyan-950/50 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-4 text-center">
            <TrendingUp className="w-5 h-5 text-cyan-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">Hot</p>
            <p className="text-xs text-gray-400">Trend</p>
          </div>
        </motion.div>

        {/* Event Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-4 mb-8"
        >
          <div className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-gray-800 rounded-2xl p-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-gray-400 text-sm mb-1">Date & Time</p>
                <p className="text-white font-semibold text-lg">Saturday, March 28</p>
                <p className="text-purple-400">10:00 PM - 4:00 AM</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-gray-800 rounded-2xl p-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-600 to-purple-600 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-gray-400 text-sm mb-1">Location</p>
                <p className="text-white font-semibold text-lg">Downtown LA</p>
                <p className="text-blue-400">1234 Skybar Ave, Los Angeles, CA 90015</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* About Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-400" />
            About Event
          </h2>
          <p className="text-gray-400 leading-relaxed">
            Experience the ultimate nightlife adventure at NEON NIGHTS. Join us for an
            unforgettable evening featuring world-class DJs, stunning visuals, and the most
            vibrant crowd in the city. This exclusive rooftop venue offers breathtaking views
            and an atmosphere that'll keep you dancing until dawn.
          </p>
        </motion.div>

        {/* Lineup */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
            <Music className="w-6 h-6 text-blue-400" />
            DJ Lineup
          </h2>
          <div className="space-y-3">
            {["DJ Nexus", "Luna Eclipse", "Bass Commander", "Cyber Phoenix", "Neon Drift"].map(
              (dj, index) => (
                <div
                  key={dj}
                  className="flex items-center gap-4 bg-gradient-to-r from-gray-900/50 to-transparent backdrop-blur-xl border border-gray-800 rounded-xl p-4"
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 via-pink-600 to-blue-600 flex items-center justify-center text-white font-bold">
                    {dj[0]}
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-semibold">{dj}</p>
                    <p className="text-gray-400 text-sm">
                      {index === 0 ? "Headliner" : "Special Guest"}
                    </p>
                  </div>
                  <div className="text-purple-400 text-sm">
                    {10 + index}:00 PM
                  </div>
                </div>
              )
            )}
          </div>
        </motion.div>
      </div>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-xl border-t border-gray-800 p-6">
        <div className="max-w-md mx-auto flex items-center gap-4">
          <div className="flex-1">
            <p className="text-gray-400 text-sm">Starting from</p>
            <p className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              $25
            </p>
          </div>
          <button className="flex-1 py-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-2xl text-white font-bold text-lg hover:shadow-2xl hover:shadow-purple-500/50 transition-all relative overflow-hidden group">
            <span className="relative z-10">Get Tickets</span>
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        </div>
      </div>
    </div>
  );
}
