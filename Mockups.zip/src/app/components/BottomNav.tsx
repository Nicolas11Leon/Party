import { Link, useLocation } from "react-router";
import { Flame, Wallet, User } from "lucide-react";

export function BottomNav() {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black/80 backdrop-blur-xl border-t border-purple-500/20 z-50">
      <div className="max-w-md mx-auto px-6 py-4">
        <div className="flex justify-around items-center">
          <Link
            to="/"
            className={`flex flex-col items-center gap-1 transition-all ${
              isActive("/")
                ? "text-purple-500"
                : "text-gray-500 hover:text-purple-400"
            }`}
          >
            <Flame className={`w-6 h-6 ${isActive("/") ? "fill-purple-500" : ""}`} />
            <span className="text-xs">Discover</span>
          </Link>
          <Link
            to="/wallet"
            className={`flex flex-col items-center gap-1 transition-all ${
              isActive("/wallet")
                ? "text-blue-500"
                : "text-gray-500 hover:text-blue-400"
            }`}
          >
            <Wallet className={`w-6 h-6 ${isActive("/wallet") ? "fill-blue-500" : ""}`} />
            <span className="text-xs">Wallet</span>
          </Link>
          <Link
            to="/event/1"
            className={`flex flex-col items-center gap-1 transition-all ${
              isActive("/event")
                ? "text-cyan-500"
                : "text-gray-500 hover:text-cyan-400"
            }`}
          >
            <User className={`w-6 h-6 ${isActive("/event") ? "fill-cyan-500" : ""}`} />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </div>
    </nav>
  );
}
