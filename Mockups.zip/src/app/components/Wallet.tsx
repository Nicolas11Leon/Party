import { Ticket, QrCode, Sparkles, Calendar, MapPin, Clock, Download, Share2 } from "lucide-react";
import { motion } from "motion/react";

const tickets = [
  {
    id: 1,
    event: "NEON NIGHTS",
    venue: "Skybar Rooftop",
    date: "Sat, Mar 28",
    time: "10:00 PM",
    location: "Downtown LA",
    price: "$25.00",
    status: "active",
    qrCode: true,
  },
  {
    id: 2,
    event: "ELECTRIC PULSE",
    venue: "The Vault",
    date: "Fri, Mar 27",
    time: "11:00 PM",
    location: "West Hollywood",
    price: "$35.00",
    status: "active",
    qrCode: true,
  },
  {
    id: 3,
    event: "COSMIC LOUNGE",
    venue: "Aurora Club",
    date: "Sun, Mar 29",
    time: "9:00 PM",
    location: "Beverly Hills",
    price: "$40.00",
    status: "upcoming",
    qrCode: false,
  },
];

export function Wallet() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-blue-950/20 to-black pt-12 px-4 pb-8">
      {/* Header */}
      <div className="max-w-md mx-auto mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
          Digital Wallet
        </h1>
        <p className="text-gray-400 text-sm">Your tickets & passes</p>
      </div>

      {/* Balance Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto mb-8"
      >
        <div className="relative rounded-3xl overflow-hidden">
          {/* Animated Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          
          {/* Glow Effect */}
          <div className="absolute inset-0">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-500/30 rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-0 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl" />
          </div>

          {/* Content */}
          <div className="relative p-6">
            <div className="flex justify-between items-start mb-8">
              <div>
                <p className="text-blue-200 text-sm mb-1">Total Balance</p>
                <h2 className="text-4xl font-bold text-white">$150.00</h2>
              </div>
              <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-xl border border-white/30 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
            </div>

            <div className="flex gap-3">
              <button className="flex-1 py-3 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30 text-white font-semibold hover:bg-white/30 transition-all">
                Add Funds
              </button>
              <button className="flex-1 py-3 bg-white text-purple-600 rounded-2xl font-semibold hover:bg-gray-100 transition-all">
                Withdraw
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tickets Section */}
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">My Tickets</h3>
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Ticket className="w-4 h-4" />
            <span>{tickets.length} tickets</span>
          </div>
        </div>

        <div className="space-y-4">
          {tickets.map((ticket, index) => (
            <motion.div
              key={ticket.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <TicketCard ticket={ticket} />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

interface TicketCardProps {
  ticket: typeof tickets[0];
}

function TicketCard({ ticket }: TicketCardProps) {
  const isActive = ticket.status === "active";

  return (
    <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-gray-800">
      {/* Glow effect for active tickets */}
      {isActive && (
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 via-blue-600/20 to-cyan-600/20" />
      )}

      <div className="relative p-5">
        {/* Status Badge */}
        <div className="flex justify-between items-start mb-4">
          <div
            className={`px-3 py-1 rounded-full text-xs font-semibold ${
              isActive
                ? "bg-gradient-to-r from-green-500/20 to-cyan-500/20 text-green-400 border border-green-500/30"
                : "bg-gray-800 text-gray-400 border border-gray-700"
            }`}
          >
            {isActive ? "✓ Active" : "Upcoming"}
          </div>
          <button className="text-gray-400 hover:text-white transition-colors">
            <Share2 className="w-5 h-5" />
          </button>
        </div>

        {/* Event Info */}
        <div className="mb-4">
          <h3 className="text-2xl font-bold text-white mb-1">{ticket.event}</h3>
          <p className="text-purple-400 font-medium">{ticket.venue}</p>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="w-4 h-4 text-blue-400" />
            <span className="text-gray-300">{ticket.date}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock className="w-4 h-4 text-purple-400" />
            <span className="text-gray-300">{ticket.time}</span>
          </div>
          <div className="flex items-center gap-2 text-sm col-span-2">
            <MapPin className="w-4 h-4 text-pink-400" />
            <span className="text-gray-300">{ticket.location}</span>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-dashed border-gray-700 my-4 relative">
          <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-black" />
          <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-4 h-4 rounded-full bg-black" />
        </div>

        {/* QR Code Section */}
        {ticket.qrCode ? (
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-xs mb-1">Ticket Price</p>
              <p className="text-2xl font-bold text-white">{ticket.price}</p>
            </div>
            <div className="relative">
              {/* QR Code with Glow */}
              <div className="relative w-24 h-24 rounded-2xl bg-white p-2 shadow-2xl">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-blue-500 blur-xl opacity-50" />
                <div className="relative w-full h-full bg-white rounded-xl flex items-center justify-center">
                  <QrCode className="w-16 h-16 text-black" />
                </div>
              </div>
              
              {/* Scan indicator */}
              <motion.div
                className="absolute inset-0 rounded-2xl border-2 border-cyan-400"
                initial={{ opacity: 0.3 }}
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-gray-500 text-sm">QR code will be available 24h before event</p>
          </div>
        )}

        {/* Action Buttons */}
        {isActive && (
          <div className="mt-4 flex gap-2">
            <button className="flex-1 py-2.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl text-white text-sm font-semibold hover:from-purple-500 hover:to-blue-500 transition-all shadow-lg shadow-purple-500/30">
              View Details
            </button>
            <button className="px-4 py-2.5 bg-gray-800 rounded-xl text-white hover:bg-gray-700 transition-all">
              <Download className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
